<!doctype html>
<?php
  require (plugin_dir_path( __FILE__ ).'../helper.php');
  
  $query = "SELECT * FROM `revo_mobile_variable` WHERE slug = 'intro_page' AND is_deleted = 0 ORDER BY sort ASC";

  $data = $wpdb->get_results($query, OBJECT);

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $query_data = array(
                      'slug' => 'intro_page', 
                      'title' => $_POST['title'], 
                      'sort' => $_POST['sort'], 
                      'description' => $_POST['description'], 
                    );
    if ($_FILES["fileToUpload"]["name"]) {

      $alert = array(
              'type' => 'error', 
              'title' => 'Failed to Intro Page !',
              'message' => 'Required Image', 
          );

      $uploads_url = WP_CONTENT_URL."/uploads/revo/";
      $target_dir = WP_CONTENT_DIR."/uploads/revo/";
      $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
      $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
      $newname =  md5(date("Y-m-d H:i:s")) . "." . $imageFileType;
      $is_upload_error = 0;
      if($_FILES["fileToUpload"]["size"] > 0){

          if ($_FILES["fileToUpload"]["size"] > 2000000) {
            $alert = array(
              'type' => 'error', 
              'title' => 'Uploads Error !',
              'message' => 'your file is too large. max 2Mb', 
            );
            $is_upload_error = 1;
          }

          if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" ) {
            $alert = array(
              'type' => 'error', 
              'title' => 'Uploads Error !',
              'message' => 'only JPG, JPEG & PNG files are allowed.', 
            );
            $is_upload_error = 1;
          }

          if ($is_upload_error == 0) {
            if ($_FILES["fileToUpload"]["size"] > 500000) {
              compress($_FILES["fileToUpload"]["tmp_name"],$target_dir.$newname,90);
              $query_data['image'] = $uploads_url.$newname;
            }else{
              move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_dir.$newname);
              $query_data['image'] = $uploads_url.$newname;
            }
          }
      }

      if ($query_data['image'] != '' AND !isset($_POST['id'])) {
        $wpdb->insert('revo_mobile_variable',$query_data);

        if (@$wpdb->insert_id > 0) {
          $alert = array(
            'type' => 'success', 
            'title' => 'Success !',
            'message' => 'Intro Page Added Successfully', 
          );
        }

      }

    }

    if (@$_POST['id']) {
      $alert = array(
              'type' => 'error', 
              'title' => 'Failed to Change Intro Page !',
              'message' => 'Try Again Later', 
          );
      $id = $_POST['id'];
      $where = ['id' => $id, 'slug' => 'intro_page'];
      $wpdb->update('revo_mobile_variable',$query_data,$where);
      if (@$wpdb->show_errors == false) {
        $alert = array(
          'type' => 'success', 
          'title' => 'Success !',
          'message' => 'Intro Page with ID : '.$id.' Updated Successfully', 
        );
      }
    }

    $_SESSION["alert"] = $alert;

    $data = $wpdb->get_results($query, OBJECT);
  }

  if (@$_GET['id'] AND @$_GET['is_deleted'] == 1) {
    $alert = array(
        'type' => 'error', 
        'title' => 'Data intro page Gagal Dihapus !',
        'message' => 'Try Again Later', 
      );
    $where = ['id' => $_GET['id'], 'slug' => 'intro_page'];
    $wpdb->update('revo_mobile_variable',['is_deleted' => '1'],$where);
    if (@$wpdb->show_errors == false) {
      $alert = array(
        'type' => 'success', 
        'title' => 'Success !',
        'message' => 'Intro Page Deleted Successfully', 
      );
    }

    $_SESSION["alert"] = $alert;

    $data = $wpdb->get_results($query, OBJECT);
    wp_redirect( admin_url( '/admin.php?page=revo-intro-page' ) );
    exit;
  }

?>
<html class="fixed">
<?php include (plugin_dir_path( __FILE__ ).'partials/_css.php'); ?>
<body>
  <?php include (plugin_dir_path( __FILE__ ).'partials/_header.php'); ?>
  <div class="container-fluid">
    <?php include (plugin_dir_path( __FILE__ ).'partials/_alert.php'); ?>
    <section class="panel">
          <div class="inner-wrapper pt-0">

            <!-- start: sidebar -->
            <?php include (plugin_dir_path( __FILE__ ).'partials/_sidebar.php'); ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body p-0 pl-3">
                <div class="panel-body">
                  <div class="row mb-2">
                    <div class="col-6 text-left">
                      <h4>
                        Setting Intro Page
                      </h4>
                    </div>
                    <div class="col-6 text-right">
                      <button class="btn btn-primary" type="button" data-toggle="modal" data-target="#tambahintropage">
                        <i class="fa fa-plus"></i> Add Intro Page
                      </button>
                    </div>
                  </div>
                  
                  <div class="row">
                    <?php 
                      $urutan = 1;
                      if (!empty($data)){ ?>
                      <?php foreach ($data as $key): ?>
                        <div class="col-md-4 mb-4">
                            <div class="card border-secondary h-100 shadow">
                              <div class="card-body text-center">
                                <h5 class="card-title"><?php echo $key->title; ?></h5>
                                <img src="<?php echo $key->image ?>" class=" mx-auto my-3" style="height: 150px;">
                                <p class=" px-5 mt-2 card-text"><?php echo $key->description ?></p>
                                <button 
                                  title="<?php echo $key->title; ?>" 
                                  description="<?php echo $key->description; ?>" 
                                  id="<?php echo $key->id; ?>" 
                                  sort="<?php echo $key->sort; ?>" 
                                  type="button" class="btn btn-primary ubah">Update</button>
                                <a href="<?php echo admin_url( '/admin.php?page=revo-intro-page')."&id=".$key->id."&is_deleted=1" ?>" class="btn btn-danger" onclick='return confirm("Are you sure ?")'>Delete</a>
                              </div>
                            </div>
                        </div>
                      <?php 
                        $urutan += 1;
                        endforeach;
                       ?>
                    <?php }else{ ?>
                      <div class="col-12 text-center mt-10">
                        <img src="<?php echo get_logo() ?>" class="img-fluid mr-3" style="width: 150px">
                        <h4 class="mb-0 mt-3">Empty !</h4>
                      </div>
                    <?php } ?>
                  </div>

                </div>
            </section>
        </div>
    </section>
    <div class="modal fade" id="tambahintropage" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title font-weight-600" id="exampleModalLabel">Tambah Intro Page</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form method="POST" action="#" enctype="multipart/form-data">
              <div class="form-group">
                <span>Title</span>
                <input type="text" class="form-control" name="title"  placeholder="*Input Title" required>
              </div>
              <div class="form-group">
                <span>Description</span>
                <textarea placeholder="*Input Description" name="description" rows="2" class="form-control" required></textarea>
              </div>
              <div class="form-group">
                <span>Sort To</span>
                <input type="number" class="form-control" name="sort" value="<?php echo $urutan ?>" placeholder="*Input Order" required>
              </div>
              <div class="form-group">
                <span>Image</span>
                <input type="file" class="form-control" name="fileToUpload" required>
                <div class="text-right">
                  <small class="text-danger">Best Size : 400 X 200px</small>
                </div>
              </div>
              <div class="mt-2 text-right">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
             </form>
          </div>
        </div>
      </div>
    </div>
    <div class="modal fade" id="ubahintropage" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title font-weight-600" id="titleModal"></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form method="POST" action="#" enctype="multipart/form-data">
              <div class="form-group">
                <span>Title</span>
                <input type="text" class="form-control" name="title" id="title" placeholder="*Input Title" required>
                <input type="hidden" class="form-control" name="id" id="id" required>
              </div>
              <div class="form-group">
                <span>Description</span>
                <textarea placeholder="*Input Description" name="description" id="description" rows="2" class="form-control" required></textarea>
              </div>
              <div class="form-group">
                <span>Sort To</span>
                <input type="number" class="form-control" name="sort" id="sort" placeholder="*Input Order" required>
              </div>
              <div class="form-group">
                <span>Image</span>
                <input type="file" class="form-control" name="fileToUpload">
                <div class="text-right">
                  <small class="text-danger">Best Size : 400 X 200px</small>
                </div>
              </div>
              <div class="mt-2 text-right">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
             </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
<?php include (plugin_dir_path( __FILE__ ).'partials/_js.php');  ?>
<script type="text/javascript">
    $('.ubah').click(function () {
      var title = $(this).attr('title');
      var id = $(this).attr('id');
      var sort = $(this).attr('sort');
      var description = $(this).attr('description');

      $("#titleModal").html("Ubah Intro Page " + id);
      $("#title").val(title);
      $("#id").val(id);
      $("#description").val(description);
      $("#sort").val(sort);

      $('#ubahintropage').modal('show');
    });
</script>
</html>