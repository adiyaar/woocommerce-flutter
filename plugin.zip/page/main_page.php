<!doctype html>
<?php
  require (plugin_dir_path( __FILE__ ).'../helper.php');
  
  $query_logo = "SELECT * FROM `revo_mobile_variable` WHERE slug = 'logo' LIMIT 1";
  $query_splash = "SELECT * FROM `revo_mobile_variable` WHERE slug = 'splashscreen' LIMIT 1";
  $query_kontak = "SELECT * FROM `revo_mobile_variable` WHERE slug = 'kontak' LIMIT 3 ";
  $query_cs = "SELECT * FROM `revo_mobile_variable` WHERE slug = 'cs'";
  $query_about = "SELECT * FROM `revo_mobile_variable` WHERE slug = 'about'";

  $data_logo = $wpdb->get_row($query_logo, OBJECT);
  $data_splash = $wpdb->get_row($query_splash, OBJECT);
  $data_cs = $wpdb->get_row($query_cs, OBJECT);
  $data_about = $wpdb->get_row($query_about, OBJECT);
  $data_kontak = $wpdb->get_results($query_kontak, OBJECT);

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_FILES["fileToUploadSplash"]["name"]) {
      $query_data = array(
                      'slug' => 'splashscreen', 
                      'image' => '', 
                      'description' => $_POST['description'], 
                    );

      $alert = array(
              'type' => 'error', 
              'title' => 'Failed to Change SplashScreen !',
              'message' => 'Required Image', 
          );

      $uploads_url = WP_CONTENT_URL."/uploads/revo/";
      $target_dir = WP_CONTENT_DIR."/uploads/revo/";
      $target_file = $target_dir . basename($_FILES["fileToUploadSplash"]["name"]);
      $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
      $newname =  md5(date("Y-m-d H:i:s")) . "." . $imageFileType;
      $is_upload_error = 0;
      if($_FILES["fileToUploadSplash"]["size"] > 0){

          if ($_FILES["fileToUploadSplash"]["size"] > 2000000) {
            $alert = array(
              'type' => 'error', 
              'title' => 'Uploads Error !',
              'message' => 'your file is too large. max 2Mb', 
            );
            $is_upload_error = 1;
          }

          if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" ) {
            $alert = array(
              'type' => 'error', 
              'title' => 'Uploads Error !',
              'message' => 'only JPG, JPEG & PNG files are allowed.', 
            );
            $is_upload_error = 1;
          }

          if ($is_upload_error == 0) {
            if ($_FILES["fileToUploadSplash"]["size"] > 500000) {
              compress($_FILES["fileToUploadSplash"]["tmp_name"],$target_dir.$newname,90);
              $query_data['image'] = $uploads_url.$newname;
            }else{
              move_uploaded_file($_FILES["fileToUploadSplash"]["tmp_name"], $target_dir.$newname);
              $query_data['image'] = $uploads_url.$newname;
            }
          }
      }

      if ($query_data['image'] != '') {
        if ($data_splash == NULL || empty($data_splash)) {

              $wpdb->insert('revo_mobile_variable',$query_data);

              if (@$wpdb->insert_id > 0) {
                $alert = array(
                  'type' => 'success', 
                  'title' => 'Success !',
                  'message' => 'Splashscreen Updated Successfully', 
                );
              }
            
        }else{

            $where = ['id' => $data_splash->id];
            $wpdb->update('revo_mobile_variable',$query_data,$where);
            
            if (@$wpdb->show_errors == false) {
              $alert = array(
                'type' => 'success', 
                'title' => 'Success !',
                'message' => 'Splashscreen Updated Successfully', 
              );
            }

        }
      }

      $_SESSION["alert"] = $alert;

      $data_splash = $wpdb->get_row($query_splash, OBJECT);
    }
    if ($_FILES["fileToUploadLogo"]["name"]) {
      $query_data = array(
                      'slug' => 'logo', 
                      'title' => $_POST['title'], 
                      'image' => '', 
                      'description' => 'logo', 
                    );

      $alert = array(
              'type' => 'error', 
              'title' => 'Failed to Change Logo !',
              'message' => 'Required Image', 
          );

      $uploads_url = WP_CONTENT_URL."/uploads/revo/";
      $target_dir = WP_CONTENT_DIR."/uploads/revo/";
      $target_file = $target_dir . basename($_FILES["fileToUploadLogo"]["name"]);
      $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
      $newname =  md5(date("Y-m-d H:i:s")) . "." . $imageFileType;
      $is_upload_error = 0;
      if($_FILES["fileToUploadLogo"]["size"] > 0){

          if ($_FILES["fileToUploadLogo"]["size"] > 2000000) {
            $alert = array(
              'type' => 'error', 
              'title' => 'Uploads Error Logo !',
              'message' => 'your file is too large. max 2Mb', 
            );
            $is_upload_error = 1;
          }

          if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" ) {
            $alert = array(
              'type' => 'error', 
              'title' => 'Uploads Error Logo !',
              'message' => 'only JPG, JPEG & PNG files are allowed.', 
            );
            $is_upload_error = 1;
          }

          if ($is_upload_error == 0) {
            if ($_FILES["fileToUploadLogo"]["size"] > 500000) {
              compress($_FILES["fileToUploadLogo"]["tmp_name"],$target_dir.$newname,90);
              $query_data['image'] = $uploads_url.$newname;
            }else{
              move_uploaded_file($_FILES["fileToUploadLogo"]["tmp_name"], $target_dir.$newname);
              $query_data['image'] = $uploads_url.$newname;
            }
          }
      }

      if ($query_data['image'] != '') {
        if ($data_logo == NULL || empty($data_logo)) {

              $wpdb->insert('revo_mobile_variable',$query_data);

              if (@$wpdb->insert_id > 0) {
                $alert = array(
                  'type' => 'success', 
                  'title' => 'Success !',
                  'message' => 'Logo Updated Successfully', 
                );
              }
            
        }else{

            $where = ['id' => $data_logo->id];
            $wpdb->update('revo_mobile_variable',$query_data,$where);
            
            if (@$wpdb->show_errors == false) {
              $alert = array(
                'type' => 'success', 
                'title' => 'Success !',
                'message' => 'Logo Updated Successfully', 
              );
            }

        }
      }

      $_SESSION["alert"] = $alert;

      $data_logo = $wpdb->get_row($query_logo, OBJECT);
    }

    if (@$_POST['slug']) {
      if ($_POST['slug'] == 'kontak') {

        $success = 0;
        $where_wa = array(
          'slug' => 'kontak', 
          'title' => 'wa',
        );

        $success = insert_update_MV($where_wa,$_POST['id_wa'],$_POST['number_wa']);

        $where_phone = array(
          'slug' => 'kontak', 
          'title' => 'phone',
        );

        $success = insert_update_MV($where_phone,$_POST['id_tel'],$_POST['number_tel']);

        $where_sms = array(
          'slug' => 'kontak', 
          'title' => 'sms', 
        );

        $success = insert_update_MV($where_sms,$_POST['id_sms'],$_POST['number_sms']);

        if ($success > 0) {
          $data_kontak = $wpdb->get_results($query_kontak, OBJECT);
          $alert = array(
            'type' => 'success', 
            'title' => 'Success !',
            'message' => 'Contact Updated Successfully', 
          );
        }else{
          $alert = array(
            'type' => 'error', 
            'title' => 'error !',
            'message' => 'Contact Failed to Update', 
          );
        }

        $_SESSION["alert"] = $alert;

      }

      if ($_POST['slug'] == 'cs' || $_POST['slug'] == 'about') {
        $success = 0;
        $query_data = array(
          'slug' => $_POST['slug'], 
          'title' => $_POST['title'], 
          'description' => $_POST['description'], 
        );

        if ($_POST['id'] != 0) {
          $where = ['id' => $_POST['id']];
          $wpdb->update('revo_mobile_variable',$query_data,$where);
          
          if (@$wpdb->show_errors == false) {
            $success = 1;
          }
        }else{
          $wpdb->insert('revo_mobile_variable',$query_data);
          if (@$wpdb->insert_id > 0) {
            $success = 1;
          }
        }

        if ($success) {
          $data_cs = $wpdb->get_row($query_cs, OBJECT);
          $data_about = $wpdb->get_row($query_about, OBJECT);
          
          $alert = array(
            'type' => 'success', 
            'title' => 'Success !',
            'message' => $_POST['title'].' Success to Update', 
          );
        }else{
          $alert = array(
            'type' => 'error', 
            'title' => 'error !',
            'message' => $_POST['title'].' Failed to Update', 
          );
        }

        $_SESSION["alert"] = $alert;
      }
    }
  }

?>
<html class="fixed sidebar-light">
<?php include (plugin_dir_path( __FILE__ ).'partials/_css.php'); ?>
<body>
  <?php include (plugin_dir_path( __FILE__ ).'partials/_header.php'); ?>
  <div class="container-fluid">
    <?php include (plugin_dir_path( __FILE__ ).'partials/_alert.php'); ?>
    <section class="panel">
      <div class="inner-wrapper pt-0">

        <!-- start: sidebar -->
        <?php include (plugin_dir_path( __FILE__ ).'partials/_sidebar.php'); ?>
        <!-- end: sidebar -->

      <section role="main" class="content-body p-0 pl-3">
          <section class="panel mb-3">
            <div class="panel-body">
              <div class="row mb-2">
                <div class="col-6 text-left">
                  <h4>
                    Setting Logo Apps
                  </h4>
                </div>
              </div>
              <div class="row mb-2 mt-5">
                  <div class="col-12">
                    <div class="portlet light bordered">
                        <div class="portlet-body row">
                          <div class="col-sm-4 py-2 px-10">
                              <div class="thumbnail-gallery my-auto text-center">
                                <a class="img-thumbnail lightbox my-auto" style="border:unset;" href="<?=isset($data_logo->image)? $data_logo->image : get_logo() ?>" data-plugin-options='{ "type":"image" }'>
                                  <img class="img-responsive" src="<?=isset($data_logo->image) ? $data_logo->image : get_logo() ?>" style="width: 100px">
                                  <span class="zoom">
                                    <i class="fa fa-search"></i>
                                  </span>
                                </a>
                              </div>
                          </div>
                          <div class="col-sm-4">
                            <form method="POST" action="#" enctype="multipart/form-data">
                              <div class="form-group mb-1">
                                <span>Image</span>
                                <input type="file" class="form-control" name="fileToUploadLogo" required>
                                <small class="text-danger">Best Size : 100 x 100px</small>
                              </div>
                              <div class="form-group">
                                <span>Title Apps</span>
                                <input type="text" class="form-control" name="title" value="<?php echo $data_logo->title ?>" required>
                              </div>
                              <div class="mt-3 text-right">
                                <button type="submit" class="btn btn-primary">Submit</button>
                              </div>
                            </form>
                          </div>
                       </div> 
                    </div>
                  </div>
              </div>
            </div>
          </section>
          <section class="panel mb-3">
            <div class="panel-body">
              <div class="row mb-2">
                <div class="col-6 text-left">
                  <h4>
                    General Settings
                  </h4>
                </div>
              </div>
              <div class="row mb-2 mt-3">
                  <div class="col-6">
                      <span>Contact</span>
                      <form method="post" action="#">
                        <div class="card mt-3">
                            <div class="form-group row">
                              <label for="inputEmail3" class="col-4 col-form-label">WhatsApp</label>
                              <div class="col-8">
                                <?php 
                                  $id = 0;
                                  $value = '';
                                  if ($data_kontak) {
                                    foreach ($data_kontak as $key){
                                      if ($key->title == 'wa') {
                                        $id = $key->id;
                                        $value = $key->description;
                                      }
                                    }
                                  }
                                ?>
                                    <input type="number" class="form-control" name="number_wa" placeholder="ex: 628XXXXXXX" value="<?= $value ?>" required>
                                    <input type="hidden" name="id_wa" value="<?php echo $id  ?>">
                                <?php 
                                    
                                ?>
                              </div>
                            </div>
                            <div class="form-group row">
                              <label for="inputEmail3" class="col-4 col-form-label">No Telp</label>
                              <div class="col-8">
                                <?php 
                                  $id = 0;
                                  $value = '';
                                  if ($data_kontak) {
                                    foreach ($data_kontak as $key){
                                      if ($key->title == 'phone') {
                                        $id = $key->id;
                                        $value = $key->description;
                                      }
                                    }
                                  }
                                ?>
                                <input type="number" class="form-control" name="number_tel" placeholder="ex: 628XXXXXXX" value="<?= $value ?>" required>
                                <input type="hidden" name="id_tel" value="<?php echo $id ?>">
                              </div>
                            </div>
                            <div class="form-group row">
                              <label for="inputEmail3" class="col-4 col-form-label">SMS</label>
                              <div class="col-8">
                                <?php 
                                  $id = 0;
                                  $value = '';
                                  if ($data_kontak) {
                                    foreach ($data_kontak as $key){
                                      if ($key->title == 'sms') {
                                        $id = $key->id;
                                        $value = $key->description;
                                      }
                                    }
                                  }
                                ?>
                                <input type="number" class="form-control" name="number_sms" placeholder="ex: 628XXXXXXX" value="<?= $value ?>" required>
                                <input type="hidden" name="id_sms" value="<?php echo $id  ?>">
                              </div>
                            </div>
                            <input type="hidden" name="slug" value="kontak">
                            <div class="text-right">
                                <input type="submit" class="btn btn-sm btn-primary" name="submit" value="Submit"/>
                            </div>
                      
                        </div>
                      </form>
                  </div>
                  <div class="col-6">
                    <div class="row">
                        <div class="col-12">
                            <span>Link URL</span>
                            <form method="post" action="#">
                              <div class="card mt-3">
                                  <div class="form-group row">
                                    <label for="inputEmail3" class="col-5 col-form-label">About</label>
                                    <div class="col-7">
                                      <input type="text" class="form-control" name="description" placeholder="ex: https://revoapps.id/about" value="<?= isset($data_about->description)? $data_about->description : '' ?>" required>
                                      <input type="hidden" name="slug" value="about">
                                      <input type="hidden" name="title" value="<?= isset($data_about->title)? $data_about->title : 'link about' ?>">
                                      <input type="hidden" name="id" value="<?= $data_about->id ?>">
                                    </div>
                                  </div>

                                  <div class="text-right">
                                      <input type="submit" class="btn btn-sm btn-primary" name="submit" value="Submit"/>
                                  </div>
                            
                              </div>
                            </form>
                        </div>
                        <div class="col-12">
                            <form method="post" action="#">
                              <div class="card mt-3">
                                  <div class="form-group row">
                                    <label for="inputEmail3" class="col-5 col-form-label">Customer Support</label>
                                    <div class="col-7">
                                      <input type="text" class="form-control" name="description" placeholder="ex: https://revoapps.id/customer-suport" value="<?= isset($data_cs->description)? $data_cs->description : '' ?>" required>
                                      <input type="hidden" name="slug" value="cs">
                                      <input type="hidden" name="title" value="<?= isset($data_cs->title)? $data_cs->title : 'customer service' ?>">
                                      <input type="hidden" name="id" value="<?= $data_cs->id ?>">
                                    </div>
                                  </div>

                                  <div class="text-right">
                                      <input type="submit" class="btn btn-sm btn-primary" name="submit" value="Submit"/>
                                  </div>
                            
                              </div>
                            </form>
                        </div>
                    </div>
                  </div>
              </div>
            </div>
          </section>
          <section class="panel mb-3">
            <div class="panel-body">
              <div class="row mb-2">
                <div class="col-6 text-left">
                  <h4>
                    Setting Splash Screen
                  </h4>
                </div>
              </div>
              <div class="row mb-2">
                  <div class="col-12">
                    <div class="portlet light bordered">
                        <div class="portlet-body row">
                          <div class="col-sm-4 py-2 px-8">
                            <div class="card">
                              <div class="card-body text-center">

                                <div class="thumbnail-gallery my-auto py-5 px-8">
                                  <a class="img-thumbnail lightbox my-auto w-100" style="border:unset;" href="<?=isset($data_splash->image)? $data_splash->image : get_logo() ?>" data-plugin-options='{ "type":"image" }'>
                                    <img class="img-responsive w-100" src="<?=isset($data_splash->image) ? $data_splash->image : get_logo() ?>">
                                    <span class="zoom">
                                      <i class="fa fa-search"></i>
                                    </span>
                                  </a>
                                </div>
                                <p class="font-size-xl" id="title"><?=isset($data_splash->description)? $data_splash->description : 'Welcome'?></p>
                              </div>
                            </div>
                          </div>
                          <div class="col-sm-4" style="padding-top: 25px;">
                            <form method="POST" action="#" enctype="multipart/form-data">
                              <div class="form-group">
                                <span>Image</span>
                                <input type="file" class="form-control" name="fileToUploadSplash" required>
                                <small class="text-danger">Best Size : 200 x 200 px</small>
                              </div>
                              <div class="form-group">
                                <span>Description</span>
                                <input type="text" class="form-control" id="description" name="description" value="<?=isset($data_splash->description)? $data_splash->description : 'Welcome'?>"  placeholder="title" required>
                              </div>
                              <div class="mt-3">
                                <button type="submit" class="btn btn-primary">Submit</button>
                              </div>
                            </form>
                          </div>
                       </div> 
                    </div>
                  </div>
              </div>
            </div>
          </section>
      </section>
    </div>
    </section>
  </div>
</body>
<?php include (plugin_dir_path( __FILE__ ).'partials/_js.php'); ?>
</html>